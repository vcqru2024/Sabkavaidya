﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DesktopModules_FORM_homepage_test : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Include the JavaScript file dynamically if needed
            Page.ClientScript.RegisterClientScriptInclude("homepage_js", ResolveUrl("~/DesktopModules/YourModuleName/js/homepage.js"));
        }
    }
}